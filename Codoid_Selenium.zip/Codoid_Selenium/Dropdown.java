import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Dropdown {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Home-PC\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/dropdownsPractise/");
		
		//Create a Webelement and assign the locator of the dropdown to it:
		
	 WebElement dropdownelement = driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency"));
	 
	 //Select tag-> to use select attributes -> create the object of select class:
	 Select dropdown = new Select(dropdownelement);
	 System.out.println("The Currencies from dropdown are:");
	 
	 //Method 1 -> Select by Index:
	 dropdown.selectByIndex(0);
	 System.out.println(dropdown.getFirstSelectedOption().getText());
	 Thread.sleep(1000);
	 
	 //Method 2 -> Select by Visible Text:
	 dropdown.selectByVisibleText("AED");
	 System.out.println(dropdown.getFirstSelectedOption().getText());
	 Thread.sleep(1000);
	 
	 //Method 3 -> Select by Value:
	 dropdown.selectByValue("USD");
	 System.out.println(dropdown.getFirstSelectedOption().getText());
	 Thread.sleep(1000);
	 
	 driver.findElement(By.id("divpaxinfo")).click();
		
		for(int i=1;i<5;i++) {
		driver.findElement(By.id("hrefIncAdt")).click();
		}
		System.out.println(driver.findElement(By.id("divpaxinfo")).getText());
		
		for(int i=1;i<3;i++) {
		driver.findElement(By.id("hrefIncChd")).click();
		}
		System.out.println(driver.findElement(By.id("divpaxinfo")).getText());
		
		for(int i=1;i<3;i++) {
		driver.findElement(By.id("hrefIncInf")).click();
		}
		System.out.println(driver.findElement(By.id("divpaxinfo")).getText());
		
		driver.findElement(By.id("btnclosepaxoption")).click();
		
		//Departure & arrival 
		driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXTaction")).click();
		driver.findElement(By.xpath("//a[@value='MAA']")).click();
		driver.findElement(By.xpath("(//a[@value='BKK'])[2]")).click();
		
	 
	 
	}

}
