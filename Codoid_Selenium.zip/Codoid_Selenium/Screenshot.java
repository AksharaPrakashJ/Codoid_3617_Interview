import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.commons.io.FileUtils;


public class Screenshot {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Home-PC\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.apple.com/");
		
		//taking the screenshot
		File scrnshotimg = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				
		//saving the screenshot that we took:
		FileUtils.copyFile(scrnshotimg, new File("C:\\Users\\Home-PC\\Desktop\\apple.png"));
	}
}
